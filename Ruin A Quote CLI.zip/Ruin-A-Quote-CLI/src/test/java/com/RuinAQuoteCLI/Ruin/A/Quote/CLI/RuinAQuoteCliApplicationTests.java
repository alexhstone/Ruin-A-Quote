package com.RuinAQuoteCLI.Ruin.A.Quote.CLI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RuinAQuoteCliApplicationTests {

	@Test
	void contextLoads() {
	}

}
